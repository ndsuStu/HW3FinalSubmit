import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { AddContactComponent } from './add-contact/add-contact.component';
import { ContactComponent } from './contact/contact.component';
import { EditContactComponent } from './edit-contact/edit-contact.component';

// import { ViewControlService } from './view-control.service';
// import { ContactListService } from './contact-list.service';

@NgModule({
  declarations: [
    AppComponent,
    AddContactComponent,
    ContactComponent,
    EditContactComponent
  ],
  imports: [
    BrowserModule, 
    FormsModule
  ],
  // providers: [ViewControlService, ContactListService],
  bootstrap: [AppComponent]
})
export class AppModule { }
