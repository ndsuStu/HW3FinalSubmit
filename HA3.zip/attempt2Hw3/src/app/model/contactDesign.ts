export interface Contact {
    firstName: string;
    lastName: string;
    phone: number;
    email: string;
    company: string;
}