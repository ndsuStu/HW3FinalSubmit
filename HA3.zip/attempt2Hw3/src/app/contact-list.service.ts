import { Injectable } from '@angular/core';
import { merge } from 'rxjs';
import { isArray } from 'util';
import { Contact } from "./model/contactDesign";

@Injectable({
  providedIn: 'root'
})
export class ContactListService {

  constructor() { }

  contacts: Contact[] = [
    { 
        firstName: "Evan",
        lastName: "Dramko",
        company: "NDSU",
        phone: 7010000004,
        email: "evan.dramko@ndsu.edu"
    } 
]

addContact(cntct: Contact){
    this.contacts.push(cntct);
    console.log("contact-list service, addContact");
}

removeContact(loc: number){
    this.contacts.splice(loc, 1);
    console.log("contact-list service, removeContact");


    // this.contacts.forEach((value, index) => {
    //     if(value === cntct){
    //         this.contacts.splice(index, 1);
    //     }
    // });
}

replaceContact(cntct: Contact, loc: number){
    this.contacts[loc] = cntct;
    console.log("contact-list service, replaceContact: newName = " + cntct.firstName + " " + cntct.lastName);

}

sortInitial(){
    //this.mergeSort(this.contacts, 0, this.contacts.length-1);
    console.log("sortInitial called");
}

// mergeSort(sortArray: Contact[], lower: number, top: number){
//    // console.log("mergeSort reached");
//     if(top <= lower){
//         return; 
//     }
//     let middle = Math.ceil(lower + (top-lower)/2);
//     this.mergeSort(sortArray, (middle+1), top);
//     this.mergeSort(sortArray, lower, middle);
//     this.combine(sortArray, lower, middle, top);
//   //  console.log("mergeSort called");
//   //  console.log("result is: " + arr[0].firstName + "   " + arr[1].firstName);
// }

// combine(sortArray: Contact[], lower: number, middle: number, top: number){
//     //console.log("combine reached");
//     let res = sortArray.slice(lower, (top+1));
//     let lower1 = lower;
//     let lower2 = middle+1;
//     let i = lower;
//     while(lower1 <= middle && lower2 <= top){
//         const v1 = res[lower1-lower];
//         const v2 = res[lower2-lower];
//         if(v1.lastName.charAt[0] > v2.lastName.charAt[0]){
//             sortArray[i++] = v1;
//             lower1++;
//         } else {
//             sortArray[i++] = v2;
//             lower2++;
//         }
//     }
//     while(lower1 <= middle) { sortArray[i++] = res[lower1++ -lower];}
//     while(lower2 <= middle) { sortArray[i++] = res[lower2++ - lower];}
//     //console.log("combine called");
// }

//===========================================================================================================
// mergeSort(sortArr: Array<Contact>): Array<Contact>{
//     console.log("mergeSort called");
//     if(sortArr.length == 1){
//         return sortArr;
//     }

//     let middle = Math.ceil(sortArr.length/2);
//     let list1: Array<Contact> = sortArr.slice(0, middle);
//     let list2: Array<Contact> = sortArr.slice(middle, sortArr.length);

//     var list3;
//     //let list3: Array<Contact> = [];
//     list3 = merge(this.mergeSort(list1), this.mergeSort(list2));
//     console.log("mergeSort end reached");
//     return list3;
// }

// merge(list1: Array<Contact>, list2: Array<Contact>): Array<Contact>{
//     console.log("merge called");
//     let list3: Array<Contact> = [];

//     while((list1.length != 0) || (list2.length != 0)){
//         if(list1[0].lastName > list2[0].lastName){
//             list3.push(list2[0]);
//             list2.shift();
//         }else{
//             list3.push(list1[0]);
//             list1.shift(); 
//         }
//     }

//     while(list1.length != 0){
//         list3.push(list1[0]);
//             list1.shift(); 
//     }

//     while(list2.length != 0){
//         list3.push(list2[0]);
//             list2.shift(); 
//     }

//     return list3;
// }

insertionSort(arraySort, length){
    let i, j, key = 0;
    for(i = 1; i < length; i++){
        key = arraySort[i]
        j = i-1;
    }

    while((j>=0) && arraySort[j] > key){
        arraySort[j+1] = arraySort[j];
        j--;
    }
    arraySort[j+1] = key;

    return arraySort;
}

//=========================================================================
// partition(array: Array<Contact>, left: number = 0, right: number = array.length - 1) {
//     const pivot = array[Math.floor((right + left) / 2)];
//     let i = left;
//     let j = right;
  
//     while (i <= j) {
//       while (array[i] < pivot) {
//         i++;
//       }
  
//       while (array[j] > pivot) {
//         j--;
//       }
  
//       if (i <= j) {
//         [array[i], array[j]] = [array[j], array[i]];
//         i++;
//         j--;
//       }
//     }
  
//     return i;
//   }

// quickSort(array: Array<Contact>, left: number = 0, right: number = array.length - 1) {
//     let index;
  
//     if (array.length > 1) {
//       index = this.partition(array, left, right);
  
//       if (left < index - 1) {
//         this.quickSort(array, left, index - 1);
//       }
  
//       if (index < right) {
//         this.quickSort(array, index, right);
//       }
//     }
  
//     return array;
//   }

  


}
