import { Component } from '@angular/core';
import { Contact } from "./model/contactDesign";
import { ContactListService } from "./contact-list.service";
import { ViewControlService } from './view-control.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ContactListService, ViewControlService]
})
export class AppComponent {
  constructor(public contactslist: ContactListService, public viewChange: ViewControlService){}

    //this is in the contact-list.service.ts file
    sort(){      
      // this.contactslist.contacts = this.contacts.sort(ordering);
      // this.contactslist.contacts = this.contactslist.contacts.sort(ordering);
      // this.contacts = this.contactslist.contacts.sort(ordering);
      this.contacts = this.contacts.sort(ordering);
      //this.contacts = this.contactslist.quickSort(this.contacts);
      //this.contacts = this.insertionSort(this.contacts, this.contacts.length);
      // this.contacts = this.contactslist.insertionSort(this.contacts, this.contacts.length);
      //this.contacts = this.contactslist.mergeSort(this.contactslist.contacts);
      // this.contactslist.mergeSort(this.contactslist.contacts, 0, this.contacts.length-1);
      // this.contactslist.sortInitial();
    }

  //============================================================
// addView: boolean = true;
// editView: boolean = true;

// setAddViewFalse(){
//   this.addView = !this.addView;
// }


  //============================================================
  //create copies of the view-controlling variables
  addViewApp: boolean = false;
  editViewApp: boolean = false;
  contacts: Array<Contact> = [];
  

  ngOnInit(): void {
    this.addViewApp = this.viewChange.addView;
    this.editViewApp = this.viewChange.editView;
    this.contacts = this.contactslist.contacts;
  }

//this is in the view-control.service.ts file
  setAddViewTrue(){
    this.viewChange.addView = true;
    // this.viewChange.setAddTrue();
    // this.viewChange.addViewUpdated.subscribe((addView: boolean) => (this.addViewApp = addView));
  }

//   insertionSort(arraySort, length){
//     console.log("insertionSort called");
//     let i, j, key = 0;
//     for(i = 1; i < length; i++){
//         key = arraySort[i]
//         j = i-1;
//     }

//     while((j>=0) && arraySort[j] > key){
//         arraySort[j+1] = arraySort[j];
//         j--;
//     }
//     arraySort[j+1] = key;

//     console.log(arraySort[1].lastName + " " + arraySort[2].lastName + " " + arraySort[3].lastName);
//     return arraySort;
// }
}
function ordering(a: Contact, b: Contact){
  console.log("ordering was called");
  if(a.lastName > b.lastName){
    console.log("option 1");
    return 1;
  }else if(a.lastName < b.lastName){
    console.log("option 2");
    return -1;
  }else{
    console.log("option 3");
    return 0;
  }
}


