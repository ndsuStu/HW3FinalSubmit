import { Component, OnInit, Input } from '@angular/core';
import { Contact } from '../model/contactDesign';
import { ContactListService } from '../contact-list.service';
import { ViewControlService } from '../view-control.service';


@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css']
})
export class EditContactComponent implements OnInit {
  //@Input() id: number = 0;
  contact: Contact = this.contactslist.contacts[this.viewChange.idVal];
  firstName = "";
  lastName = "";
  email = "";
  company = "";
  phone = 0;
  

//  constructor(public contactslist: ContactListService, public viewChange: ViewControlService) { }
constructor(public contactslist: ContactListService, public viewChange: ViewControlService) { }

  ngOnInit(): void {
    this.contact = this.contactslist.contacts[this.viewChange.idVal];
    this.firstName = this.contact.firstName;
    this.lastName = this.contact.lastName;
    this.email = this.contact.email;
    this.company = this.contact.company;
    this.phone = this.contact.phone;
  }

  saveChanges(){
    var newContact: Contact = {
      firstName: this.firstName,
      lastName: this.lastName, 
      company: this.company,
      phone: this.phone,
      email: this.email, 
    }

    this.viewChange.editView = false;
    this.contactslist.replaceContact(newContact, this.viewChange.idVal);
    this.viewChange.editView = false;

  }
}
