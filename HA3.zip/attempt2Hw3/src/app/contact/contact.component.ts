import { Component, OnInit, Input } from '@angular/core';
import { Contact } from '../model/contactDesign';
import { ContactListService } from '../contact-list.service';
import { ViewControlService } from '../view-control.service';



@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  @Input() id: number = 0;

  //declare variables (initialized in ngOnInit())
  contact: Contact = null;
  firstName: string = "";
  lastName: string = "";
  email: string = "";
  company: string = "";
  phone: number = 0;
  editViewContact: boolean = false;


  constructor(public contactslist: ContactListService, public viewChange2: ViewControlService) { }

  ngOnInit(): void {
  //initialize variables that depend on service values
  this.editViewContact = this.viewChange2.editView;
  this.contact = this.contactslist.contacts[this.id];
  this.firstName = this.contact.firstName;
  this.lastName = this.contact.lastName;
  this.email = this.contact.email;
  this.company = this.contact.company;
  this.phone = this.contact.phone;
  }

  edit(){
    this.viewChange2.idVal = this.id;
    this.viewChange2.editView = true;
  }


  delete(){
    this.contactslist.removeContact(this.id);
    //this.contactslist.removeContact(this.contact, this.id);
  }
}
